<a href="javascript:void(0)" data-toggle="tooltip" onClick="editFunc(<?php echo e($id); ?>)" data-original-title="Edit" class="edit btn btn-success edit">
    Editar
    </a>
    <a href="javascript:void(0);" id="delete-compnay" onClick="deleteFunc(<?php echo e($id); ?>)" data-toggle="tooltip" data-original-title="Delete" class="delete btn btn-danger">
    Borrar
    </a><?php /**PATH C:\xampp\htdocs\laravel\prueba1\resources\views/empleado-action.blade.php ENDPATH**/ ?>