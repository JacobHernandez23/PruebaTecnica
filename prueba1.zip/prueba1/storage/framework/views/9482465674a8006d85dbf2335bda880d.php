<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" >


        
    </head>
    <body>
        <div class="container ">
            <div class="position-absolute top-50 start-50 translate-middle">
            <h1 class="fs-1">Bienvenido Al Ajax Crud </h1>
        <a href="<?php echo e(url('/ajax-crud-datatable')); ?>" class="btn fs-2 btn-outline-success">PRESIONA PARA COMENZAR</a>
    </div>
    </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\prueba1\resources\views/welcome.blade.php ENDPATH**/ ?>